// namespaces System;

using System; // Tipos de dados fundamentais (como int, double, char etc).
using System.Data; // Formam o ADO .NET, usadas para acesso e manipulação de banco de dados.
using System.Drawing; // Desenho e elementos gráficos.
using System.IO; // Entrada e saída de dados.
using System.Threading; // Múltiplas linhas de execução (multithreading).
using System.Windows.Forms; // Cria interfaces com o usuário gráficas.
using System.Xml; // Processa dados XML.